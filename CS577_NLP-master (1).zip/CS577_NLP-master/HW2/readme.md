Implement Deep Maximum Entropy Markov Model (DMEMM) for the targeted sentiment task using Viterbi algorithm in the inference for decoding.
